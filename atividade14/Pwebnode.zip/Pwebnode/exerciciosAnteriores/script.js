const a = 4;
const b = 5;

setTimeout(()=>{
    console.log(a+b);    
})
